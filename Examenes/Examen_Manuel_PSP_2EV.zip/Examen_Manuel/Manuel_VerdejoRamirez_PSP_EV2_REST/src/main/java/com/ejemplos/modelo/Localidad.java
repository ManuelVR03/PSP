package com.ejemplos.modelo;

import java.io.Serializable;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * The persistent class for the localidad database table.
 * 
 */
@Entity
@Table(name="localidad")
@NamedQuery(name="Localidad.findAll", query="SELECT l FROM Localidad l")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Localidad implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="cod_localidad")
	private long codLocalidad;

	@Column(name="nombre_localidad")
	private String nombreLocalidad;

	private BigInteger numhabit;

	//bi-directional many-to-one association to Provincia
	@ManyToOne
	@JoinColumn(name="cod_provincia")
	private Provincia provincia;

	//bi-directional many-to-one association to Tiempo
	@OneToMany(mappedBy="localidad")
	private List<Tiempo> tiempos;

}