package com.ejemplos.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ejemplos.DTO.CreateLocalidadDTO;
import com.ejemplos.DTO.LocalidadDTO;
import com.ejemplos.DTO.LocalidadDTOConverter;
import com.ejemplos.excepciones.ApiError;
import com.ejemplos.excepciones.ProvinciaNotFoundException;
import com.ejemplos.modelo.Localidad;
import com.ejemplos.modelo.LocalidadRepository;
import com.ejemplos.modelo.ProvinciaRepository;
import com.fasterxml.jackson.core.JsonProcessingException;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/RESTiempo")
public class LocalidadController {

	@Autowired
	private LocalidadRepository localidadRepositorio;
	
	@Autowired
	private ProvinciaRepository provinciaRepositorio;
	
	@Autowired
	private LocalidadDTOConverter localidadDTOConverter;
	
	@GetMapping("/localidad")
	public ResponseEntity<?> obtenerTodas() {
		List<Localidad> result = localidadRepositorio.findAll();
		if (result.isEmpty()) {
			return ResponseEntity.notFound().build();
		}
		else {
			List<LocalidadDTO> dtoList = result.stream().map(localidadDTOConverter::convertirADto).collect(Collectors.toList());
			return ResponseEntity.ok(dtoList);
		}
	}
	
	@PostMapping("/localidad")
	public ResponseEntity<?> nuevaLocalidad(@RequestBody CreateLocalidadDTO nueva){
		if(!provinciaRepositorio.existsById(nueva.getProvinciaCodProvincia())) throw new ProvinciaNotFoundException(nueva.getProvinciaCodProvincia());
		Localidad l = localidadDTOConverter.convertirALoc(nueva);
		return ResponseEntity.ok(localidadRepositorio.save(l));
	}
	
	@ExceptionHandler(ProvinciaNotFoundException.class)
	public ResponseEntity<ApiError> handleProvinciaNoEncontrada(ProvinciaNotFoundException ex){
		ApiError apiError = new ApiError();
		apiError.setEstado(HttpStatus.NOT_FOUND);
		apiError.setFecha(LocalDateTime.now());
		apiError.setMensaje(ex.getMessage());
		apiError.setEntidad("Fallo en la entidad Provincia");
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(apiError);
	}
	
	@ExceptionHandler(JsonProcessingException.class)
	public ResponseEntity<ApiError> handleJsonMappingException(JsonProcessingException ex) {
		ApiError apiError = new ApiError();
		apiError.setEstado(HttpStatus.BAD_REQUEST);
		apiError.setFecha(LocalDateTime.now());
		apiError.setMensaje(ex.getMessage());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(apiError);
	}
}
