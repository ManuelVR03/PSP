package com.ejemplos.modelo;

import java.io.Serializable;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * The persistent class for the tiempo database table.
 * 
 */
@Entity
@Table(name="tiempo")
@NamedQuery(name="Tiempo.findAll", query="SELECT t FROM Tiempo t")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Tiempo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="cod_tiempo")
	private long codTiempo;

	@Temporal(TemporalType.DATE)
	private Date fecha;

	private String temperaturas;

	//bi-directional many-to-one association to Localidad
	@ManyToOne
	@JoinColumn(name="cod_localidad")
	private Localidad localidad;

}