package com.ejemplos.modelo;

import java.io.Serializable;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * The persistent class for the provincia database table.
 * 
 */
@Entity
@Table(name="provincia")
@NamedQuery(name="Provincia.findAll", query="SELECT p FROM Provincia p")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Provincia implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="cod_provincia")
	private String codProvincia;

	@Column(name="nombre_prov")
	private String nombreProv;

	//bi-directional many-to-one association to Localidad
	@OneToMany(mappedBy="provincia")
	private List<Localidad> localidads;
	
	public void addLocalidad(Localidad l) {
		localidads.add(l);
	}

}