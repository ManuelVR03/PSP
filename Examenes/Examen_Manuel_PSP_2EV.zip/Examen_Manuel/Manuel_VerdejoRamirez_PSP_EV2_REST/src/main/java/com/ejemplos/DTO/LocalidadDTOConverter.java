package com.ejemplos.DTO;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ejemplos.modelo.Localidad;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class LocalidadDTOConverter {
	
	@Autowired
	private ModelMapper modelMapper;
	
	public LocalidadDTO convertirADto(Localidad localidad) {
		return modelMapper.map(localidad, LocalidadDTO.class);
	}
	
	public Localidad convertirALoc(CreateLocalidadDTO createLocalidadDTO) {
		return modelMapper.map(createLocalidadDTO, Localidad.class);
	}

}
