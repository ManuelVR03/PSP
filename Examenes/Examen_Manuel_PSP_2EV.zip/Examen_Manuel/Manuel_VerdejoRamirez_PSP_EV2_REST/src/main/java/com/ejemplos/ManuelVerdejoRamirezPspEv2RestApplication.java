package com.ejemplos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManuelVerdejoRamirezPspEv2RestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManuelVerdejoRamirezPspEv2RestApplication.class, args);
	}

}
