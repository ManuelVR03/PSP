package com.ejemplos.excepciones;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class ProvinciaNotFoundException extends RuntimeException{
	private static final long serialVersionUID = 1L;
	public ProvinciaNotFoundException(String id) {
		super("No existe la provincia con codigo: " + id);
	}
}
