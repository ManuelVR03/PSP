package com.ejemplos.DTO;

import java.math.BigInteger;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class CreateLocalidadDTO {

	private long codLocalidad;
	private String nombreLocalidad;
	private BigInteger numhabit;
	private String provinciaCodProvincia;
}
