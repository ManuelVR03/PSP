package com.ejemplos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManuelVerdejoRamirezPspEv2RestApplicationTests {

	@Test
	void contextLoads() {
	}

}
